from django.contrib import admin
from .models import *
# Register your models here.
admin.site.register(LeaveApplication)
admin.site.register(LeaveCategory)
admin.site.register(LeaveType)
admin.site.register(LeaveReason)
admin.site.register(LeaveBalance)
admin.site.register(HolidayList)
admin.site.register(LeaveApplicationDetails)
admin.site.register(LeaveRegister)
admin.site.register(FY)
